[Rose Song], [300243581], [D], [October 17, 2018]

This assignment is [enter percent]% complete.


------------------------
Question one (PhoneNumbers) status:

Complete

------------------------
Question two (CylinderStats) status:

Complete

------------------------
Question three (Cylinder) status:

Complete

------------------------
Question four (Box) status:

Complete

------------------------
Question five (Email) status:

Complete
